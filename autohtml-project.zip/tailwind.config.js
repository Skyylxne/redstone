
// remember to use module.exports instead of tailwind.config in production
tailwind.config = undefined
          